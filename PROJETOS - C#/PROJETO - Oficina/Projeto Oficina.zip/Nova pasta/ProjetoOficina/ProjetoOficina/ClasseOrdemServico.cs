﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoOficina
{
    class ClasseOrdemServico
    {
        public string codOrdem { get; set; }
        public string codVeiculo { get; set; }
        public string hora { get; set; }
        public string dataEntrada { get; set; }
        public string dataSaida { get; set; }
        public string tipoServico { get; set; }
        public string valor { get; set; }

        ClassAcessoBD bd = new ClassAcessoBD();

        public bool InserirNovaOrdemServico()
        {
            try
            {
                bd.Conectar();
             // Executa o insert
                bd.ExecutarComandosSql(String.Format("INSERT into OrdemServico (codOrdem,Veiculo_codVeiculo,hora,DataEntrada,DataSaida,TipoServico,ValorServico) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}',{7})",codOrdem,codVeiculo,hora,dataEntrada,dataSaida,tipoServico,valor));
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message + "Erro ao inserir ordem de serviço.");
            }
            //Desconecta no banco 
            bd.Desconectar();
            return true;
        }
    }
}
