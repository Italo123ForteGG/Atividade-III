﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoOficina
{
    public partial class OrdemSevico : Form
    {
        ClasseOrdemServico ordemServico = new ClasseOrdemServico();
        public OrdemSevico()
        {
            InitializeComponent();
        }

        private void btnGerarOrdem_Click(object sender, EventArgs e)
        {
            ordemServico.codOrdem = txtCodigo.Text;
            ordemServico.codVeiculo = txtPlaca.Text;
            ordemServico.hora = txtHora.Text;
            ordemServico.dataEntrada = txtDataEntrada.Text;
            ordemServico.dataSaida= txtDataSaida.Text;
            ordemServico.tipoServico = txtTipoServico.Text;
            ordemServico.valor = float.Parse(txtValor.Text);
            ordemServico.codMecanico = int.Parse(txtCodigoMecanico.Text);
            ordemServico.nomeCliente = txtNome.Text;

            if (ordemServico.InserirNovaOrdemServico() == true)
            {
                MessageBox.Show("Ordem de Serviço Registrada");
            }
            else
            {
                MessageBox.Show("Erro ao registrar ordem de serviço");
            }
        }
    }
}
