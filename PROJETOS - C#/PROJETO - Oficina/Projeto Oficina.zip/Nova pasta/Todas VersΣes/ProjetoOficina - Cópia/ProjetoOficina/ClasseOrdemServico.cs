﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjetoOficina
{
    class ClasseOrdemServico
    {
        public string codOrdem { get; set; }
        public string codVeiculo { get; set; }
        public string nomeCliente { get; set; }
        public string hora { get; set; }
        public string dataEntrada { get; set; }
        public string dataSaida { get; set; }
        public string tipoServico { get; set; }
        public int    codMecanico { get; set; }
        public float valor { get; set; }

        ClassAcessoBD bd = new ClassAcessoBD();

        public bool InserirNovaOrdemServico()
        {
            try
            {
                bd.Conectar();
             // Executa o insert
                bd.ExecutarComandosSql(String.Format("INSERT INTO OrdemServico (codOrdem,Veiculo_codVeiculo,nomeCliente,hora,DataEntrada,DataSaida,TipoServico,Funcionario_codFunc,ValorServico) VALUES ('{0}','{1}','{2}','{3}','{4}','{5}','{6}',{7},{8})",codOrdem,codVeiculo,nomeCliente,hora,dataEntrada,dataSaida,tipoServico,codMecanico,valor));
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message + "Erro ao inserir ordem de serviço.");
            }
            //Desconecta no banco 
            bd.Desconectar();
            return true;
        }
    }
}
