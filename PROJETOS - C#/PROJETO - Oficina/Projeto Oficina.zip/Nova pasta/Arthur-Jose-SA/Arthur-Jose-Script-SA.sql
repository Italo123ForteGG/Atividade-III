﻿CREATE DATABASE dbLogin
GO
USE dbLogin
GO
--DROP DATABASE  dbLogin
CREATE TABLE  Usuario (
	idUsuario	INT IDENTITY (1,1) PRIMARY KEY,
	nome		VARCHAR(60),
	telefone	CHAR(11),
	email		VARCHAR(60),
	cpf			CHAR(11),
	nomeUsuario VARCHAR(60),
	senha		VARCHAR(60),
	tipoUsuario	INT
);

CREATE TABLE CalcDesmatamento(
	idCalculo			INT IDENTITY (2000,1) PRIMARY KEY,
	ano					INT,
	estado				VARCHAR(40),
	numArvoresCortadas	INT,
	volArvoresCortadas	INT,
	arvoresARepor		INT,
	valorAPagar			MONEY,
	);

CREATE TABLE RegDesmatamento(
	idRegistro			INT IDENTITY (100,1) PRIMARY KEY,
	ano					INT,
	estado				VARCHAR(30),
	numArvoresCortadas	INT,
	volArvoresCortadas	INT,
	);

INSERT INTO Usuario VALUES ('João','3333444','joao@gmail.com','1115410','Joao100','123',1)
INSERT INTO RegDesmatamento VALUES (2018,'Minas Gerais',50,32)
INSERT INTO CalcDesmatamento VALUES (2018,'Minas Gerais',50,32,15,137.00)

SELECT*FROM RegDesmatamento
SELECT*FROM CalcDesmatamento
SELECT*FROM Usuario

