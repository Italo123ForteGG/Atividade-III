﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class RegDesmatamento : Form
    {
        ClassRegDesmatamento registro = new ClassRegDesmatamento();

        public RegDesmatamento()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if ((txtAno.Text != "") || (txtEstado.Text != "") || (txtNumCortadas.Text != "") || (txtVolCortadas.Text != ""))
            {
                registro.ano = int.Parse(txtAno.Text);
                registro.estado = txtEstado.Text;
                registro.numArvoresCortadas = int.Parse(txtNumCortadas.Text);
                registro.volArvoresCortadas = int.Parse(txtVolCortadas.Text);

                if (registro.InserirNovoRegistro() == true)
                {
                    MessageBox.Show("Registro cadastrado com sucesso!");
                    txtAno.Text = "";
                    txtEstado.Text = "";
                    txtNumCortadas.Text = "";
                    txtVolCortadas.Text = "";
                }
                else
                {
                    MessageBox.Show("Erro ao registrar");
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.");
            }
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            TelaPrincipal AbrirTelaPrincipal = new TelaPrincipal();
            this.Hide();
            AbrirTelaPrincipal.Show();
        }
    }
}
