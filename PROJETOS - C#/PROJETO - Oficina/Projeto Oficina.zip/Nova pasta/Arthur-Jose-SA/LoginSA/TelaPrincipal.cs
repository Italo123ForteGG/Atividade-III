﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class TelaPrincipal : Form
    {
        public TelaPrincipal()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegDesmatamento RegitrarDesmatamento = new RegDesmatamento();
            this.Hide();
            RegitrarDesmatamento.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            EditarUsuario TelaEditarUsuario = new EditarUsuario();
            this.Hide();
            TelaEditarUsuario.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            TelaLogin AbrirTelaLogin = new TelaLogin();
            this.Hide();
            AbrirTelaLogin.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CalcularDesmatamento AbrirCalcularDesmatamento = new CalcularDesmatamento();
            this.Hide();
            AbrirCalcularDesmatamento.Show();
        }
    }
}
