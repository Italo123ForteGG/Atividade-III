﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class TelaLogin : Form
    {
        ClassUsuario usuario = new ClassUsuario();
        
        public TelaLogin()
        {
            InitializeComponent();
            // Set to no text.  
            textBox2.Text = "";
            // The password character is an asterisk.  
            textBox2.PasswordChar = '*';
            // The control will allow no more than 14 characters.  
            textBox1.MaxLength = 14;
        }
        private void btnNovoCad_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "admin")&& (textBox2.Text == "123"))
            {
                    TelaPrincipal TelaAdiministrador = new TelaPrincipal();
                    this.Hide();
                    TelaAdiministrador.Show();
            }
            else
            { 
                usuario.nomeUsuario = textBox1.Text;
                usuario.senha = textBox2.Text;
                DataTable dt = usuario.RealizarLogin();

                if (dt.Rows.Count == 1)
                {
                    //Como usar os dados desta tabela
                    string nomeUsuario = dt.Rows[0]["nomeUsuario"].ToString();
                    string senha = dt.Rows[0]["senha"].ToString();

                    TelaAssistente HomePageAssistente= new TelaAssistente();
                    this.Hide();
                    HomePageAssistente.Show();
                    }
                else
                {
                    MessageBox.Show("Login e senha errados");
                }
            }
        }
    }
}
