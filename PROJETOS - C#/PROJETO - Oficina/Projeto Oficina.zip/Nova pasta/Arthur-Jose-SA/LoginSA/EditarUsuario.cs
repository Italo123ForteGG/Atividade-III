﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class EditarUsuario : Form
    {
        int idClienteClicado = 0;
        ClassUsuario usuario = new ClassUsuario();

        public EditarUsuario()
        {
            InitializeComponent();
        }

        private void EditarUsuario_Load_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource = usuario.RetTodosUsuarios();
        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells["IdUsuario"].Value.ToString() != "")
            {
                idClienteClicado = int.Parse(dataGridView1.Rows[e.RowIndex].Cells["IdUsuario"].Value.ToString());
            }
            txtNome.Text = dataGridView1.Rows[e.RowIndex].Cells["nome"].Value.ToString();
            txtNomeUsuario.Text = dataGridView1.Rows[e.RowIndex].Cells["nomeUsuario"].Value.ToString();
            txtSenha.Text = dataGridView1.Rows[e.RowIndex].Cells["senha"].Value.ToString();
            txtEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["email"].Value.ToString();
            txtCpf.Text = dataGridView1.Rows[e.RowIndex].Cells["cpf"].Value.ToString();
            txtTelefone.Text = dataGridView1.Rows[e.RowIndex].Cells["telefone"].Value.ToString();
            txtTipoUsuario.Text = dataGridView1.Rows[e.RowIndex].Cells["tipoUsuario"].Value.ToString();
        }

        private void btnEditar_Click_1(object sender, EventArgs e)
        {
            usuario.nome = txtNome.Text;
            usuario.nomeUsuario = txtNomeUsuario.Text;
            usuario.senha = txtSenha.Text;
            usuario.email = txtEmail.Text;
            usuario.cpf = txtCpf.Text;
            usuario.telefone =txtTelefone.Text;
            usuario.tipoUsuario = int.Parse(txtTipoUsuario.Text);

            if (usuario.Editar(idClienteClicado) == true)
            {
                //MessageBox.Show("Usuario editado com sucesso");
                dataGridView1.DataSource = usuario.RetTodosUsuarios();
            }
            else
            {
                MessageBox.Show("Erro ao tentar editar");
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if ((txtCpf.Text != "") || (txtEmail.Text != "") || (txtNome.Text != "") || (txtNomeUsuario.Text != "") || (txtSenha.Text != "") || (txtTelefone.Text != ""))
            {
                usuario.nome = txtNome.Text;
                usuario.nomeUsuario = txtNomeUsuario.Text;
                usuario.senha = txtSenha.Text;
                usuario.email = txtEmail.Text;
                usuario.cpf = txtCpf.Text;
                usuario.telefone = txtTelefone.Text;
                usuario.tipoUsuario = int.Parse(txtTipoUsuario.Text);

                if (usuario.InserirNovoUsuario() == true)
                {
                    MessageBox.Show("Usuário cadastrado com sucesso!");
                    dataGridView1.DataSource = usuario.RetTodosUsuarios();
                }
                else
                {
                    MessageBox.Show("Erro ao cadastrar usuário");
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            TelaPrincipal AbrirTelaPrincipal = new TelaPrincipal();
            this.Hide();
            AbrirTelaPrincipal.Show();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            usuario.nome = txtNome.Text;
            usuario.nomeUsuario = txtNomeUsuario.Text;
            usuario.senha = txtSenha.Text;
            usuario.email = txtEmail.Text;
            usuario.cpf = txtCpf.Text;
            usuario.telefone = txtTelefone.Text;
            usuario.tipoUsuario = int.Parse(txtTipoUsuario.Text);

            if (usuario.Excluir(idClienteClicado) == true)
            {
                //MessageBox.Show("Usuario editado com sucesso");
                dataGridView1.DataSource = usuario.RetTodosUsuarios();
            }
            else
            {
                MessageBox.Show("Erro ao tentar editar");
            }
        }

        private void txtPesquisa_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = usuario.RetUsuario(txtPesquisa.Text);
        }

        private void txtPesquisarCpf_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = usuario.RetUsuarioCpf(txtPesquisarCpf.Text);
        }

        private void txtPesquisarE_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = usuario.RetUsuarioE(txtPesquisarE.Text);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Text = "";
            txtNomeUsuario.Text = "";
            txtSenha.Text = "";
            txtEmail.Text = "";
            txtCpf.Text = "";
            txtTelefone.Text = "";
            txtTipoUsuario.Text = "" ;
        }
    }
}
