﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginSA
{
    class ClassRegDesmatamento
    {
        //Propriedades
        public int IdRegistro { get; set; }
        public int ano{ get; set; }
        public string estado{ get; set; }
        public int numArvoresCortadas{ get; set; }
        public int volArvoresCortadas{ get; set; }
        public int  arvoresARepor { get; set; }
        public decimal valorAPagar { get; set; }
    //Objetos
    ClassAcessoBD bd = new ClassAcessoBD();

        public bool InserirNovoRegistro()
        {
            try
            {
                //Conecta no banco
                bd.Conectar();

                //Executa o insert
                bd.ExecutarComandosSql(String.Format("INSERT into RegDesmatamento (ano,estado,numArvoresCortadas,volArvoresCortadas) VALUES ({0},'{1}',{2},{3})",ano,estado,numArvoresCortadas,volArvoresCortadas));

                //Desconecta no banco 
                bd.Desconectar();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + "Erro ao resgistrar desmatamento. ");
            }
        }

        public DataTable RetTodosRegistros()
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM RegDesmatamento"));
            bd.Desconectar();

            return dt;
        }

        public bool Excluir(int idRegistroClicado)
        {
            bd.Conectar();
            bd.ExecutarComandosSql(String.Format("DELETE FROM RegDesmatamento WHERE idRegistro = {0}", idRegistroClicado));
            MessageBox.Show("Registro excluído com sucesso.");
            bd.Desconectar();
            return true;
        }

        public bool Editar(int idRegistroClicado)
        {
            bd.Conectar();
            bd.ExecutarComandosSql(String.Format("UPDATE RegDesmatamento SET ano = {0},estado ='{1}', numArvoresCortadas = {2}, volArvoresCortadas  = {3} WHERE idRegistro = {4}", ano, estado, numArvoresCortadas, volArvoresCortadas, idRegistroClicado));
            bd.Desconectar();
            return true;
        }

    }
}
