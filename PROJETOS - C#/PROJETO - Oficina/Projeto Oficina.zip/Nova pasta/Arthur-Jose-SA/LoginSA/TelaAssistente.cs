﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class TelaAssistente : Form
    {
        public TelaAssistente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegDesmatamento RegitrarDesmatamento = new RegDesmatamento();
            this.Hide();
            RegitrarDesmatamento.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            TelaLogin AbrirTelaLogin = new TelaLogin();
            this.Hide();
            AbrirTelaLogin.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CalcularDesmatamento AbrirCalcularDesmatamento = new CalcularDesmatamento();
            this.Hide();
            AbrirCalcularDesmatamento.Show();
        }

        private void btnSair2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
