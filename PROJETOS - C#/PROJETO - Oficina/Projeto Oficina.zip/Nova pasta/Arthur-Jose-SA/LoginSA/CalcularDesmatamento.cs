﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSA
{
    public partial class CalcularDesmatamento : Form
    {
        Double somaReposicao = 1;
        Double somaPagar = 1;
        int idRegistroClicado = 0;
        ClassRegDesmatamento registro = new ClassRegDesmatamento();

        public CalcularDesmatamento()
        {
            InitializeComponent();
        }

        private void CalcularDesmatamento_Load(object sender, EventArgs e)
        {
            dgvRegistro.DataSource = registro.RetTodosRegistros();
        }

        private void dgvRegistro_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvRegistro.Rows[e.RowIndex].Cells["IdRegistro"].Value.ToString() != "")
            {
                idRegistroClicado = int.Parse(dgvRegistro.Rows[e.RowIndex].Cells["IdRegistro"].Value.ToString());
            }
            txtAno.Text = dgvRegistro.Rows[e.RowIndex].Cells["ano"].Value.ToString();
            txtEstado.Text = dgvRegistro.Rows[e.RowIndex].Cells["estado"].Value.ToString();
            txtNumCortadas.Text = dgvRegistro.Rows[e.RowIndex].Cells["numArvoresCortadas"].Value.ToString();
            txtVolCortadas.Text = dgvRegistro.Rows[e.RowIndex].Cells["volArvoresCortadas"].Value.ToString();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            registro.ano = int.Parse(txtAno.Text);
            registro.estado= txtEstado.Text;
            registro.numArvoresCortadas =int.Parse(txtNumCortadas.Text);
            registro.volArvoresCortadas = int.Parse(txtVolCortadas.Text);

            if (registro.Excluir(idRegistroClicado) == true)
            {
                dgvRegistro.DataSource = registro.RetTodosRegistros();
            }
            else
            {
                MessageBox.Show("Erro ao tentar excluir");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            TelaAssistente AbrirTelaAssistente = new TelaAssistente();
            this.Hide();
            AbrirTelaAssistente.Show();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            {
                registro.ano = int.Parse(txtAno.Text);
                registro.estado = txtEstado.Text;
                registro.numArvoresCortadas = int.Parse(txtNumCortadas.Text);
                registro.volArvoresCortadas = int.Parse(txtVolCortadas.Text);

                if (registro.Editar(idRegistroClicado) == true)
                {
                    MessageBox.Show("Registro editado.");
                    dgvRegistro.DataSource = registro.RetTodosRegistros();
                }
                else
                {
                    MessageBox.Show("Erro ao tentar editar");
                }
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            Double cortadas = 0;
            Double volume = 0;

            cortadas = Double.Parse(txtNumCortadas.Text);
            volume = Double.Parse(txtVolCortadas.Text);

            somaReposicao = (volume*6);
            somaPagar = (cortadas * 0.75);

            txtResultado2.Text = ("" + somaPagar);
            txtResultado.Text = (""+somaReposicao);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAno.Text = "";
            txtEstado.Text = "";
            txtNumCortadas.Text = "";
            txtVolCortadas.Text = "";
        }
    }
}
