﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LoginSA
{
    class ClassUsuario
    {
        //Propriedades
        public int IdCliente { get; set; }
        public string nome { get; set; }
        public string telefone { get; set; }
        public string cpf { get; set; }
        public string email { get; set; }
        public string nomeUsuario { get; set; }
        public string senha { get; set; }
        public int tipoUsuario { get; set; }
        //Objetos
        ClassAcessoBD bd = new ClassAcessoBD();

        public bool InserirNovoUsuario()
        {
            try
            {
                //Conecta no banco
                bd.Conectar();

                //Executa o insert
                bd.ExecutarComandosSql(String.Format("INSERT into Usuario (nome,telefone,email,cpf,nomeUsuario,senha,tipoUsuario) VALUES ('{0}',{1},'{2}',{3},'{4}','{5}',{6})", nome,telefone,email,cpf,nomeUsuario,senha,tipoUsuario));

                //Desconecta no banco 
                bd.Desconectar();
                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + "Erro ao inserir cliente. ");
            }
        }

        public DataTable RealizarLogin()
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM Usuario WHERE (nomeUsuario LIKE '{0}') AND (senha LIKE '{1}')", nomeUsuario, senha));
            bd.Desconectar();
            return dt; 
        }

        public DataTable RetTodosUsuarios()
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM Usuario"));
            bd.Desconectar();

            return dt;
        }

        public bool Editar(int idClienteClicado)
        {
            bd.Conectar();
            bd.ExecutarComandosSql(String.Format("UPDATE Usuario SET nome = '{0}',telefone = {1},	email='{2}',cpf='{3}',nomeUsuario ='{4}',senha = '{5}',tipoUsuario	= {6} WHERE idUsuario = {7}", nome,telefone,email,cpf,nomeUsuario,senha,tipoUsuario,idClienteClicado));
            bd.Desconectar();
            return true;
        }
        public bool Excluir(int idClienteClicado)
        {
            bd.Conectar();
            bd.ExecutarComandosSql(String.Format("DELETE FROM Usuario WHERE idUsuario = {0}",idClienteClicado));
            MessageBox.Show("Usuário excluído com sucesso.");
            bd.Desconectar();
            return true;
        }


        public DataTable RetUsuario(string nome)
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM Usuario WHERE nome LIKE '%{0}%' ", nome));
            bd.Desconectar();

            return dt;
        }
        public DataTable RetUsuarioCpf(string cpf)
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM Usuario WHERE cpf LIKE '%{0}%' ", cpf));
            bd.Desconectar();

            return dt;
        }
        public DataTable RetUsuarioE(string email)
        {
            bd.Conectar();
            DataTable dt = bd.RetDataTable(String.Format("SELECT * FROM Usuario WHERE email LIKE '%{0}%' ", email));
            bd.Desconectar();

            return dt;
        }
    }
}
