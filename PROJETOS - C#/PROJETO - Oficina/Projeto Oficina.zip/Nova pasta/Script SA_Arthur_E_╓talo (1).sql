CREATE DATABASE dbSitua��oDeAprendizagem

GO
USE dbSitua��oDeAprendizagem
-- DROP DATABASE dbSitua��oDeAprendizagem
GO
CREATE TABLE Cliente (
	codCliente					INT PRIMARY KEY,
	CEP							INT,
	Endere�o					VARCHAR(30),
	Bairro						VARCHAR(30),
	Cidade						VARCHAR(30),
	UF							CHAR(2),
	Celular						BIGINT,
	Email						VARCHAR(80)
	);

CREATE TABLE Fisico (
	codFisico				INT PRIMARY KEY,
	Cliente_codCliente		INT,
	CPF						varchar(20),
	RG						VARCHAR(20),
	nome					VARCHAR(80),
	dataNasc				DATE,
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Juridico (
	codJuridico				INT PRIMARY KEY,
	Cliente_codCliente		INT,
	CNPJ					VARCHAR(30),
	nomeFantasia			VARCHAR(30),
	representante			VARCHAR(80),
	cpfRepresentante		VARCHAR(20),
	siteWeb					VARCHAR(100),
	razaoSocial				VARCHAR(30),
	inscricaoEstdual		VARCHAR(20),
	dataAbertura			DATE,
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Veiculo (
	codVeiculo						CHAR(8) PRIMARY KEY,
	Cliente_codCliente				INT,
	Modelo							VARCHAR(20),
	Ano								INT,
	Cor								VARCHAR(20),
	Marca							VARCHAR(20),
	kmAtual							INT,
	Combustivel						VARCHAR(20),
	Observa��o						VARCHAR(80),			
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Especialidade (
	codEspec	CHAR(3) PRIMARY KEY,
	Nome				VARCHAR(80),
	descricao			VARCHAR(80),
	valorHora			MONEY
	);

CREATE TABLE Indica (
	codIndicacao			INT PRIMARY KEY,
	Cliente_codCliente		INT,
	possui_codCliente		CHAR(1),
	codClienteQueIndicou	INT,
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Funcionario (
	codFunc							INT PRIMARY KEY,
	Especialidade_codEspec	CHAR(3),
	Nome							VARCHAR(80),
	numHoras						INT,
	salario							MONEY,
	FOREIGN KEY(Especialidade_codEspec) REFERENCES Especialidade (codEspec)
	);

CREATE TABLE OrdemServico (
	codOrdem			CHAR (7) PRIMARY KEY,
	Veiculo_codVeiculo  CHAR(8),
	Hora				TIME,
	DataEntrada			DATE,
	DataSaida			DATE,
	TipoServico			VARCHAR(80),
	ValorServico		MONEY,
	FOREIGN KEY(Veiculo_codVeiculo) REFERENCES Veiculo (codVeiculo)
	);
	
CREATE TABLE Servico (
	codServico			            INT PRIMARY KEY,
	OrdemServico_codOrdem			CHAR (7),
	Especialidade_codEspec			CHAR(3),
	Hora							TIME,
	Data							DATE,
	FOREIGN KEY(OrdemServico_codOrdem) REFERENCES OrdemServico(codOrdem),
	FOREIGN KEY(Especialidade_codEspec) REFERENCES Especialidade (codEspec)
	);

CREATE TABLE Pagamento (
	codPgto				CHAR(7) PRIMARY KEY,
	OrdemServico_codOrdem	CHAR (7),
	TipoPagto				VARCHAR(20),
	Valor					MONEY,
	Desconto				MONEY,
	Situacao				VARCHAR(20),
	FOREIGN KEY(OrdemServico_codOrdem) REFERENCES OrdemServico(codOrdem)
	);

CREATE TABLE Parcela (
	codParcela					CHAR(7) PRIMARY KEY,
	Pagamento_codPgto		CHAR(7),
	QuantParcela				INT,
	valorParcela				MONEY,
	FOREIGN KEY (Pagamento_codPgto) REFERENCES Pagamento (codPgto)
	);


BEGIN TRANSACTION

INSERT INTO Cliente VALUES (0001,31110230,'Avenida Cristiano Machado','Venda Nova','Belo Horizonte','MG',31958458553,'amadeufranco@gmail.com'),
	                       (0002,32065170,'Rua Ametista','Contagem','Quintas do Jacuba','MG',31975265945,'Flaviapacheco@hotmail.com'),
						   (0003,31110230,'Rua Aldeia de Joanes','Jardim Ibirapuera','S�o Paulo','SP',4198456345,'Royalautocenter@gmail.com')

INSERT INTO Fisico VALUES (1001,0001,'691.962.140-15','17.747.238-8','Amadeu Franco','21/04/1980'),
						  (1002,0002,'816.047.400-86','15.144.479-1','Fl�via Pacheco','14/12/1998')

INSERT INTO Juridico VALUES (1003,0003,'61.809.758/0001-60','Royal Auto Center','Pedro Bastos','546.405.008-66','www.royalautocenter.com.br','Royal Auto Center S/A','957.367.365.762','25/09/1950')

INSERT INTO indica  VALUES (12,0001,'S',502),
						   (13,0002,'N',NULL),
                           (14,0003,'S',502)

INSERT INTO Veiculo VALUES ('GZY-4039',0001,'Gol','2018','Prata','Wolksvagwn',600,'Flex',NULL),
						 ('GQB-1168',0002,'Uno','2017','Vermelho','Fiat',2000,'Gasolina',NULL),
						 ('GCX-8502',0003,'Palio','2005','Preto','Fiat',4680,'Gasolina',NUll)

INSERT INTO Especialidade VALUES ('MTR','Motor',NULL,100.00),
								 ('SPC','Suspen��o',NULL,200.00),
								 ('FRE','Freio',NULL,300.00),
								 ('ELE','El�trica',NULL,150.00),
								 ('ETR','Eletronica',NULL,350.00)

INSERT INTO Funcionario VALUES  (991,'MTR','Rogerio Carvalho',48,0),
								(992,'SPC','Augusto Ferreira',50,0),
								(993,'FRE','Paulo Costa',30,0),
								(994,'ELE','Andre Santos',42,0),
								(995,'ETR','Carlos Freitas',48,0)
IF(@@ERROR <> 0)
	ROLLBACK
ELSE
	COMMIT 

SELECT*FROM FUNCIONARIO

UPDATE Funcionario 
	set salario = (SELECT (E.valorHora*F.numHoras) 
	                FROM Especialidade E INNER JOIN Funcionario F 
		     		ON (E.codEspec = F.Especialidade_codEspec) WHERE codFunc=991)
   WHERE codFunc=991
UPDATE Funcionario 
	set salario = (SELECT (E.valorHora*F.numHoras) 
	                FROM Especialidade E INNER JOIN Funcionario F 
		     		ON (E.codEspec = F.Especialidade_codEspec) WHERE codFunc=992)
   WHERE codFunc=992
UPDATE Funcionario 
	set salario = (SELECT (E.valorHora*F.numHoras) 
	                FROM Especialidade E INNER JOIN Funcionario F 
		     		ON (E.codEspec = F.Especialidade_codEspec) WHERE codFunc=993)
   WHERE codFunc=993
UPDATE Funcionario 
	set salario = (SELECT (E.valorHora*F.numHoras) 
	                FROM Especialidade E INNER JOIN Funcionario F 
		     		ON (E.codEspec = F.Especialidade_codEspec) WHERE codFunc=994)
   WHERE codFunc=994
   UPDATE Funcionario 
	set salario = (SELECT (E.valorHora*F.numHoras) 
	                FROM Especialidade E INNER JOIN Funcionario F 
		     		ON (E.codEspec = F.Especialidade_codEspec) WHERE codFunc=995)
   WHERE codFunc=995

INSERT INTO OrdemServico VALUES ('MTR-001','GZY-4039','08:35','21/08/2018','25/08/2018','Baixa Pot�ncia',350.00),
								('SPC-001','GQB-1168','10:16','23/08/2018','23/08/2018','Ru�dos e batidas nas rodas',245.00),
								('FRE-001','GCX-8502','19:40','18/08/2018','27/08/2018','O Veiculo ou pedal vibrar ao pisar no pedal de freio',110.00)

INSERT INTO Servico	VALUES(555,'MTR-001','MTR','15:50','24/08/2018'),
						  (556,'SPC-001','SPC','18:30','23/08/2018'),
					      (557,'FRE-001','FRE','17:15','25/08/2018')

INSERT INTO Pagamento VALUES    ('DEB-001','MTR-001','D�bito',0.00,0.00,'A Pagar'),
								('CRE-001','SPC-001','Cr�dito',0.00,0.00,'A Pagar'),
								('VIS-001','FRE-001','Vista',0,0.00,'Pago')

UPDATE Pagamento 
SET Valor = (SELECT (O.valorServico)
	FROM  Pagamento AS P INNER JOIN  OrdemServico AS O
	ON (P.OrdemServico_codOrdem = O.codOrdem)WHERE codPgto ='DEB-001')
WHERE codPgto ='DEB-001'

UPDATE Pagamento 
SET Valor = (SELECT (O.valorServico)
	FROM  Pagamento AS P INNER JOIN  OrdemServico AS O
	ON (P.OrdemServico_codOrdem = O.codOrdem)WHERE codPgto ='CRE-001')
WHERE codPgto ='CRE-001'

UPDATE Pagamento 
SET Valor = (SELECT (O.valorServico)
	FROM  Pagamento AS P INNER JOIN  OrdemServico AS O
	ON (P.OrdemServico_codOrdem = O.codOrdem)WHERE codPgto ='VIS-001')
WHERE codPgto ='VIS-001'

INSERT INTO Parcela VALUES  (051,'DEB-001',2,175.00),
							(052,'CRE-001',5,49.00)

SELECT*FROM Cliente 
SELECT*FROM Fisico
SELECT*FROM Juridico
SELECT*FROM indica
SELECT*FROM Veiculo
SELECT*FROM Especialidade
SELECT*FROM Funcionario
SELECT*FROM OrdemServico
SELECT*FROM Servico
SELECT*FROM Pagamento
SELECT*FROM Parcela

CREATE TABLE Auditoria
(
	codAuditoria INT IDENTITY (20,1) PRIMARY KEY,
	nome         VARCHAR(80),
	data         DATE,
	Servico_codServico     INT,
	Funcionario_codFunc    INT,
	Especialidade_codEspec CHAR(3), 
	OrdemServico_codOrdem  CHAR(7),

	FOREIGN KEY (Servico_codServico) REFERENCES Servico (codServico),
	FOREIGN KEY (Funcionario_codFunc) REFERENCES Funcionario (codFunc),
	FOREIGN KEY (Especialidade_codEspec) REFERENCES Especialidade (codEspec),
	FOREIGN KEY (OrdemServico_codOrdem) REFERENCES OrdemServico (codOrdem)
)


-- PROCEDURE cpOS (Cria��o Procedure Ordem Ser)
GO
CREATE PROCEDURE  cpOS
	@OrdemServico VARCHAR(50)
	AS
		SELECT * FROM OrdemServico
		WHERE  codOrdem = @OrdemServico
-- PROCEDURE Ppagamento
GO
CREATE PROCEDURE Ppagamento
	@TipoPagto VARCHAR(30),
	@Valor     INT
	AS 
		SELECT * FROM Pagamento
		WHERE (TipoPagto = @TipoPagto) AND (Valor = @Valor)

EXECUTE Ppagamento 'Cr�dito', 245.00	

-- PROCEDURE Ffuncionario
GO
CREATE PROCEDURE Ffuncionario
	@salario MONEY
	AS 
		SELECT * FROM Funcionario
		WHERE (salario = @salario) 

EXECUTE Ffuncionario 6300.00
-- DROP PROCEDURE Ppagamento 


--Modelo f�sico: Exemplo de como inserir, alterar e excluir dados; 

--INSERT INTO Veiculo (codVeiculo,Cliente_codCliente,Modelo,Ano,Cor,Marca,Modelo,kmAtual,Combustivel,Observa��o)
--		VALUES ('GZY-4039',0001,'Gol','2018','Prata','Wolksvagwn',600,'Flex',NULL)
--ALTER TABLE Veiculo ADD Chassi CHAR(11);
--ALTER TABLE Veiculo DROP Combustivel;

--02 consultas desejar para apresentar as cl�usulas WHERE E HAVING

SELECT F.nome,F.CPF,V.codVeiculo,V.Marca,V.Modelo
	FROM Fisico  AS F INNER JOIN Cliente AS C 
	ON (F.Cliente_codCliente = C.codCliente) INNER JOIN
	Veiculo AS V ON (V.Cliente_codCliente = C.codCliente)
	WHERE codVeiculo LIKE 'GQB-1168'

SELECT Modelo,Marca,kmAtual
	FROM Veiculo
	WHERE Combustivel LIKE 'Gasolina'
	GROUP BY Modelo,Marca,kmAtual
	HAVING kmAtual < 4000

-- 5 consultas simples utilizando views
GO
CREATE VIEW vwConsultaCarros AS
	SELECT V.* FROM Veiculo AS V
	GO
SELECT*FROM vwConsultaCarros
	ORDER BY kmAtual
GO
CREATE VIEW vwOrdemServico AS
	SELECT O.* FROM OrdemServico AS O 
	GO
SELECT*FROM OrdemServico
	ORDER BY DataEntrada
GO
CREATE VIEW vwPagamento AS
	SELECT P.* FROM Pagamento AS P
	GO
SELECT*FROM vwPagamento
	WHERE Situacao LIKE 'Pago'
GO
CREATE VIEW vwEspecialidade AS
	SELECT E.* FROM Especialidade AS E
GO
SELECT*FROM vwEspecialidade
	ORDER BY Nome ASC

--04 consultas com uso de joins utilizando views

GO
CREATE VIEW vwConsultaFuncionario AS
    SELECT F.nome, E.codEspec,E.valorHora
    FROM Especialidade AS E INNER JOIN Funcionario AS F
    ON (F.Especialidade_codEspec = E.codEspec)
GO
SELECT*FROM vwConsultaFuncionario

GO
CREATE VIEW vwConsultaServicoFuncionario AS
			SELECT F.nome,E.codEspec,O.TipoServico,S.Hora,S.Data
			FROM Funcionario AS F INNER JOIN Especialidade AS E
			ON (F.Especialidade_codEspec = E.codEspec) INNER JOIN Servico AS S
			ON (S.Especialidade_codEspec = E.codEspec) INNER JOIN OrdemServico AS O
			ON (S.OrdemServico_codOrdem = O.codOrdem)
			GO
SELECT *FROM vwConsultaServicoFuncionario

GO
CREATE VIEW vwClientesMg AS
	SELECT C.Endere�o,C.Bairro,C.Cidade,F.nome
	FROM Fisico AS F INNER JOIN Cliente C
	ON (F.Cliente_codCliente = C.codCliente)
	WHERE C. UF	LIKE 'MG'
GO
SELECT*FROM vwClientesMg
GO
CREATE VIEW vwConsultaClienteVeiculo1 AS
    SELECT C.Endere�o, V.codVeiculo
    FROM Cliente AS C INNER JOIN Veiculo AS V
    ON (C.codCliente = V.CLIENTE_codCliente)
GO
SELECT*FROM vwConsultaClienteVeiculo1


--03 consultas utilizando fun��es agregadas e views
GO
CREATE VIEW vwFuncionarioSalario AS
	SELECT F.Nome,E.codEspec,F.salario
	FROM Funcionario AS F INNER JOIN Especialidade AS E 
	ON (F.Especialidade_codEspec = E.codEspec )
	WHERE salario = (SELECT MAX(salario) FROM Funcionario)
GO
SELECT*FROM vwFuncionarioSalario

GO
CREATE VIEW vwMaxServico AS
SELECT *�FROM��OrdemServico
WHERE�ValorServico� = �(SELECT��MAX(ValorServico)�FROM��OrdemServico)
GO
SELECT*FROM vwMaxServico
GO
CREATE VIEW vwMediaEspecialidade AS
SELECT *�FROM��Especialidade
WHERE�valorHora� = �(SELECT��MIN(ValorHora)�AS 'M�dia'FROM��Especialidade)
GO
SELECT*FROM vwMediaEspecialidade

--m.	(2,0 pts) 03 consultas utilizando subconsultas e views
GO
CREATE VIEW vwFuncionario1 AS
	SELECT F.* FROM Funcionario AS F
	WHERE numHoras = (SELECT MIN(numHoras) FROM Funcionario)
GO
SELECT*FROM vwFuncionario1
GO
CREATE VIEW vwPagamentoSubC AS
SELECT *�FROM��PagamentoWHERE�TipoPagto� LIKE �'Cr�dito'
GO
SELECT*FROM vwPagamentoSubC
GO
CREATE VIEW vwVeiculoSubC AS
SELECT *�FROM��VeiculoWHERE�Cor� LIKE 'Vermelho'
GO
SELECT*FROM vwVeiculoSubC


--r.	(2,0 pts) Explicando como criar usu�rios e senhas cedendo ou removendo permiss�es para acesso ao banco gerado
--SEGURAN�A DO BANCO DE DADOS
--CRIA�AO DE LOGIN
--GO
--CREATE LOGIN Estagiario WITH PASSWORD = '123'
--GO
--CREATE LOGIN Gerente WITH PASSWORD = '456'
--CRIA��O DE USUARIO
--GO
--CREATE USER Estagiario FOR LOGIN Estagiario
--GO
--CREATE USER Gerente FOR LOGIN Gerente
--GO
--USE dbSAno
--	REVOKE ALTER,DELETE,UPDATE
--	ON Pagamento FROM Estagiario
--GO
--USE dbSAno
--	REVOKE ALTER,DELETE,UPDATE
--	ON Funcionario FROM Estagiario
--GO
--USE dbSAno
--	REVOKE ALTER,DELETE,UPDATE
--	ON Cliente FROM Estagiario
--HABILITA PERMI��ES
--	GO
--USE dbSAno
--	GRANT SELECT,INSERT,ALTER,UPDATE,DELETE ON Cliente TO Gerente
--	GRANT SELECT,INSERT,ALTER,UPDATE,DELETE ON Pagamento TO Gerente
--	GRANT SELECT,INSERT,ALTER,UPDATE,DELETE ON Funcionario TO Gerente
