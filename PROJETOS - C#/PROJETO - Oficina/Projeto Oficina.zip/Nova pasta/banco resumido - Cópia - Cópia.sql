CREATE DATABASE dbOficina
-- 
GO
USE dbOficina
-- DROP DATABASE dbOficina
GO
CREATE TABLE Cliente (
	codCliente					INT PRIMARY KEY,
	CEP							INT,
	Endere�o					VARCHAR(30),
	Bairro						VARCHAR(30),
	Cidade						VARCHAR(30),
	UF							CHAR(2),
	Celular						BIGINT,
	Email						VARCHAR(80)
	);

CREATE TABLE Fisico (
	codFisico				INT PRIMARY KEY,
	Cliente_codCliente		INT,
	CPF						varchar(20),
	RG						VARCHAR(20),
	nome					VARCHAR(80),
	dataNasc				DATE,
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Juridico (
	codJuridico				INT PRIMARY KEY,
	Cliente_codCliente		INT,
	CNPJ					VARCHAR(30),
	nomeFantasia			VARCHAR(30),
	representante			VARCHAR(80),
	cpfRepresentante		VARCHAR(20),
	siteWeb					VARCHAR(100),
	razaoSocial				VARCHAR(30),
	inscricaoEstdual		VARCHAR(20),
	dataAbertura			DATE,
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);

CREATE TABLE Veiculo (
	codVeiculo						CHAR(8) PRIMARY KEY,
	Cliente_codCliente				INT,
	Modelo							VARCHAR(20),
	Ano								INT,
	Cor								VARCHAR(20),
	Marca							VARCHAR(20),
	kmAtual							INT,
	Combustivel						VARCHAR(20),
	Observa��o						VARCHAR(80),			
	FOREIGN KEY(Cliente_codCliente) REFERENCES Cliente (codCliente)
	);



CREATE TABLE OrdemServico (
	codOrdem			CHAR (7) PRIMARY KEY,
	Veiculo_codVeiculo  CHAR(8),
	Hora				TIME,
	DataEntrada			DATE,
	DataSaida			DATE,
	TipoServico			VARCHAR(80),
	ValorServico		MONEY,
	FOREIGN KEY(Veiculo_codVeiculo) REFERENCES Veiculo (codVeiculo)
	);
	
CREATE TABLE Servico (
	codServico			            INT PRIMARY KEY,
	OrdemServico_codOrdem			CHAR (7),
	Especialidade_codEspec			CHAR(3),
	Hora							TIME,
	Data							DATE,
	FOREIGN KEY(OrdemServico_codOrdem) REFERENCES OrdemServico(codOrdem)
	);



INSERT INTO Cliente VALUES (0001,31110230,'Avenida Cristiano Machado','Venda Nova','Belo Horizonte','MG',31958458553,'amadeufranco@gmail.com'),
	                       (0002,32065170,'Rua Ametista','Contagem','Quintas do Jacuba','MG',31975265945,'Flaviapacheco@hotmail.com'),
						   (0003,31110230,'Rua Aldeia de Joanes','Jardim Ibirapuera','S�o Paulo','SP',4198456345,'Royalautocenter@gmail.com')

INSERT INTO Fisico VALUES (1001,0001,'691.962.140-15','17.747.238-8','Amadeu Franco','1980/04/19'),
						  (1002,0002,'816.047.400-86','15.144.479-1','Fl�via Pacheco','1998/04/12')

INSERT INTO Juridico VALUES (1003,0003,'61.809.758/0001-60','Royal Auto Center','Pedro Bastos','546.405.008-66','www.royalautocenter.com.br','Royal Auto Center S/A','957.367.365.762','1950/02/09')

INSERT INTO Veiculo VALUES ('GZY-4039',0001,'Gol','2018','Prata','Wolksvagwn',600,'Flex',NULL),
						 ('GQB-1168',0002,'Uno','2017','Vermelho','Fiat',2000,'Gasolina',NULL),
						 ('GCX-8502',0003,'Palio','2005','Preto','Fiat',4680,'Gasolina',NUll)

INSERT INTO OrdemServico VALUES ('MTR-001','GZY-4039','08:35','2018/08/21','2018/04/08','Baixa Pot�ncia',350.00),
								('SPC-001','GQB-1168','10:16','2018/08/23','2018/05/03','Ru�dos e batidas nas rodas',245.00),
								('FRE-001','GCX-8502','19:40','2018/08/18','2018/02/15','O Veiculo ou pedal vibrar ao pisar no pedal de freio',110.00)

INSERT INTO Servico	VALUES(555,'MTR-001','MTR','15:50','2018/08/24'),
						  (556,'SPC-001','SPC','18:30','2018/08/25'),
					      (557,'FRE-001','FRE','17:15','2018/08/10')


SELECT*FROM Cliente 
SELECT*FROM Fisico
SELECT*FROM Juridico
SELECT*FROM Veiculo
SELECT*FROM OrdemServico
SELECT*FROM Servico
